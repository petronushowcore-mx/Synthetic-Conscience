import math, random
from statistics import mean, pstdev

MU=0.85; LAMBDA_DECAY=0.01; E_TARGET=0.50; K_HOMEOSTASIS=0.10
CW_EPS=0.20; CW_GAMMA=0.70; CW_GAIN=1.25

def user_feedback(E,C,B,alpha=0.5,beta=0.3,gamma=0.2,t_now=10,t0=0,lam=LAMBDA_DECAY):
    base=alpha*E+beta*C+gamma*B; decay=math.exp(-lam*(t_now-t0)); return base*decay

def trust_score(R,A,V,a=0.4,b=0.4,c=0.2):
    if min(R,A,V)<=0:return 0.0
    return (R**a*A**b*V**c)**(1.0/(a+b+c))

def relevance_score(S,Cx,E,a=0.5,b=0.3,c=0.2):
    if min(S,Cx,E)<=0:return 0.0
    return (S**a*Cx**b*E**c)**(1.0/(a+b+c))

def stability_score(D,Avar,Rrec):
    D=max(0.0,min(1.0,D));Avar=max(0.0,min(1.0,Avar));Rrec=max(0.0,min(1.0,Rrec))
    if min(D,Avar,Rrec)<=0:return 0.0
    return (D*Avar*Rrec)**(1.0/3.0)

def behavioral_consistency(sig_series,context_corr=0.8,a=0.6,b=0.4):
    if not sig_series:return 0.0
    sigma=pstdev(sig_series) if len(sig_series)>1 else 0.0
    sigma_norm=min(1.0,sigma/0.5); stability_internal=1.0-sigma_norm
    corr01=(context_corr+1.0)/2.0; score=a*stability_internal+b*corr01
    return max(0.0,min(1.0,score))

def raw_context_weight(trust,relevance,stability,behavioral_consistency):
    return trust*relevance*stability*behavioral_consistency

def calibrate_cw(cw,eps=CW_EPS,gamma=CW_GAMMA,gain=CW_GAIN):
    cw=eps+(1.0-eps)*(cw**gamma); cw=min(1.0,cw*gain); return cw

def mu_delta(prev_E,feedbacks,contexts,mu=MU):
    if not feedbacks or not contexts or len(feedbacks)!=len(contexts):return prev_E
    avg=mean([f*c for f,c in zip(feedbacks,contexts)])
    return mu*prev_E+(1.0-mu)*avg

def delta_E(prev_E,feedbacks,contexts,mu=MU,e_target=E_TARGET,k_homeo=K_HOMEOSTASIS):
    if not feedbacks or not contexts or len(feedbacks)!=len(contexts):return prev_E
    avg=mean([f*c for f,c in zip(feedbacks,contexts)])
    base=mu*prev_E+(1.0-mu)*avg
    return base+k_homeo*(e_target-prev_E)

def reproduce_user_case():
    prev_E=0.5
    feedbacks=[0.6386099874008259,0.5239876819699084,0.5485496045622479]
    cws_raw=[0.4536,0.3456,0.3528]
    e_no_cal=mu_delta(prev_E,feedbacks,cws_raw,mu=0.85)
    print("User case (raw) -> dE_t = {:.3f} (expected 0.458)".format(e_no_cal))
    cws_cal=[calibrate_cw(c) for c in cws_raw]
    e_cal=delta_E(prev_E,feedbacks,cws_cal,mu=MU,e_target=E_TARGET,k_homeo=K_HOMEOSTASIS)
    print("User case (calibrated) -> dE_t = {:.3f}".format(e_cal))

def run_demo(seed=7,steps=50,use_calibrated=True):
    random.seed(seed); E=0.5; series_E=[]; affect_window=[]
    for t in range(steps):
        Eu=random.uniform(0.4,0.95); Cu=random.uniform(0.3,0.9); Bu=random.uniform(0.3,0.85)
        fb=user_feedback(Eu,Cu,Bu,t_now=t,t0=max(0,t-5))
        R=random.uniform(0.6,0.95); A=random.uniform(0.6,0.9); V=random.uniform(0.5,0.85)
        tr=trust_score(R,A,V)
        S=random.uniform(0.6,0.95); Cx=random.uniform(0.5,0.9); Eth=random.uniform(0.6,0.95)
        rel=relevance_score(S,Cx,Eth)
        D=random.uniform(0.5,0.9); Avar=1.0-random.uniform(0.0,0.5); Rrec=random.uniform(0.4,0.9)
        stab=stability_score(D,Avar,Rrec)
        affect=(Eu+Cu+Bu)/3.0; affect_window.append(affect)
        if len(affect_window)>12:affect_window.pop(0)
        bc=behavioral_consistency(affect_window,context_corr=random.uniform(0.4,0.9))
        cw_raw=raw_context_weight(tr,rel,stab,bc)
        cw=calibrate_cw(cw_raw) if use_calibrated else cw_raw
        if use_calibrated:E=delta_E(E,[fb],[cw],mu=MU,e_target=E_TARGET,k_homeo=K_HOMEOSTASIS)
        else:E=mu_delta(E,[fb],[cw],mu=MU)
        series_E.append(E)
    mode="calibrated+homeostasis" if use_calibrated else "raw"
    print("dE after {} steps ({}): {:.3f} (start 0.500)".format(steps,mode,E))
    return series_E

if __name__=="__main__":
    reproduce_user_case()
    run_demo(seed=7,steps=50,use_calibrated=False)
    run_demo(seed=7,steps=50,use_calibrated=True)
